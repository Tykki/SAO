<template>
  <b-container id="footer" fluid>
        <b-row class="align-items-center">
            <b-col>
              <p class="text-left">© 2018 The Board of Trustees of the University of Illinois | <a href="https://www.vpaa.uillinois.edu/resources/web_privacy">Privacy Statement</a></p>
            </b-col>
            <b-col>
              <b-btn variant="danger" to="/old-form">Old Form</b-btn>
              <b-btn variant="primary" to="/">Home</b-btn>
              <b-btn variant="success" to="/new-form">New Form</b-btn>
            </b-col>
        </b-row>
    </b-container>
</template>

<script>
export default {
  name: 'sao-footer',
  data () {
    return {
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
/*#header{
  width: calc(100% - 300px);
  float: right;
  text-align: center;
  height: 50px;
  background-color: $navBlue;
  margin-bottom: 15px;
  color: white;
  a {
    &:hover{
      color: $accentRed;
    };
    &:last-child{
      margin: auto 24px auto 24px;
    };
      
    &:hover{
      text-decoration: none;
    };
    color: $navLink;
  }
  span{
  font-size: small;
  }
}*/

</style>
