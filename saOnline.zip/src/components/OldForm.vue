<template>
  <main class="container-fluid" id="display">
    <b-form>
        <!-- <div class="form-row"> -->
            <div class="form-group">
                <label for="inputName">Name</label>
                <input type="name" class="form-control" id="name" placeholder="Full Name">
            </div>

        <!-- </div> -->
            <div class="form-group">
                <label for="description">Description</label>
                <input type="text" class="form-control" id="description" placeholder="description">
            </div>

        <div class="form-group">
            <label for="location">Location</label>
            <input type="text" class="form-control" id="location" placeholder="1234 Main St">
        </div>
        

        <div class="form-row">

            <div class="form-group col-md-6">
                <label for="start">Start</label>
                <input type="date" class="form-control" id="start">
            </div>
            
            <div class="form-group col-md-6">
                <label for="end">End</label>
                <input type="date" class="form-control" id="end">
            </div>

        </div>
        <div class="form-row">
            
        <div class="form-group col-md-6">
            <label for="status">Status</label>
            <select id="status" class="form-control">
                <option selected>Choose...</option>
                <option>...</option>
            </select>
        </div>

        <div class="form-group col-md-6">
            <label for="category">Category</label>
            <input type="text" class="form-control" id="category">
        </div>
        </div>

        <div class="form-row">
            <div class="form-group col-md-6">
                <label for="department">Department</label>
                <input type="text" class="form-control" id="department" placeholder="Student Affairs">
            </div>

            <div class="form-group col-md-6">
                <label for="audience ">Audience</label>
                <input type="text" class="form-control" id="audience" placeholder="audience">
            </div>
      </div>

      <button type="submit" class="btn btn-primary">Submit</button>
    </b-form>
</main>
</template>

<script>
export default {
  name: 'hello',
  data () {
    return {
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
