<template>
  <main class="container-fluid" id="display">
    <section class="row">
        <article class="col-12">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Card Title</h3>
                    <strong>First Name: </strong><label id="fName">N/A</label>
                    <br>
                    <strong>Last Name: </strong><label id="lName">N/A</label>
                    <br>
                    <strong>Email: </strong><label id="email">N/A</label>
                </div>
            </div>
                
                <!-- <br>
                <strong>Department: </strong><label id="dName">N/A</label> -->

                
           
        </article>
    </section>
    <section class="row">
        <article class="col-xs-12 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Card Title</h3>
                    <p class="card-text"> Random text</p>
                </div>
            </div>
        </article>
        <article class="col-xs-12 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Card Title</h3>
                    <p class="card-text"> Random text</p>
                </div>
            </div>
        </article>
    </section>
    <section class="row">
        <article class="col-xs-12 col-sm-4">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Card Title</h3>
                    <p class="card-text"> Random text</p>
                </div>
            </div>
        </article>
        <article class="col-xs-12 col-sm-4">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Card Title</h3>
                    <p class="card-text"> Random text</p>
                </div>
            </div>
        </article>
        <article class="col-xs-12 col-sm-4">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Card Title</h3>
                    <p class="card-text"> Random text</p>
                </div>
            </div>
        </article>
        <article class="col-xs-12 col-sm-12">
            <div class="card">
                <div class="card-body">
                    <h3 class="card-title">Card Title</h3>
                    <p class="card-text"> Random text</p>
                </div>
            </div>
        </article>
    </section>
  </main>
</template>

<script>
export default {
  name: 'hello',
  data () {
    return {
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>
