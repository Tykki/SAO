<template>
  <header id="header">
    <b-container fluid>
        <b-row>
            <b-col class="justify-content-center">
                <h1 class="justify-content-center">Header</h1>  
            </b-col>
            <i id="sign-out" class="align-self-center fas fa-lg fa-sign-out-alt justify-content-end"></i>
        </b-row>
    </b-container>
  </header>
</template>

<script>
export default {
  name: 'sao-header',
  data () {
    return {
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
/*#header{
  width: calc(100% - 300px);
  float: right;
  text-align: center;
  height: 50px;
  background-color: $navBlue;
  margin-bottom: 15px;
  color: white;
  a {
    &:hover{
      color: $accentRed;
    };
    &:last-child{
      margin: auto 24px auto 24px;
    };
      
    &:hover{
      text-decoration: none;
    };
    color: $navLink;
  }
  span{
  font-size: small;
  }
}*/

</style>
