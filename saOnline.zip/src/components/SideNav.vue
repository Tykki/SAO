<template>
  <b-nav class="nav-side-menu" vertical>
    
    <div class="brand">
        <div id="toggle-wrap" class="faa-parent animated-hover">
            <i class="fas fa-lg fa-arrow-left faa-passing-reverse faa-fast"></i>
        </div>
        <strong>Student Affairs</strong>
    </div>
    <i class="fas fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>
    <div class="menu-list">
        <ul id="menu-content" class="menu-content collapse out">
            <li class="active blink">
                <a href="#">
                    <i class="fas fa-tachometer-alt fa-lg"></i> <strong> Dashboard</strong>
                </a>
            </li>
            <li id="rGroup" data-toggle="collapse" data-target="#ResourseGroup" class="collapsed">
                <a href="#"><i class="fas fa-link fa-lg"></i> <strong id="rName"> Resourse Group</strong> <span class="arrow"></span></a>
            </li>
            <ul class="sub-menu collapse" id="ResourseGroup">
                <li class="active"><a href="#"><strong id="rLink">Group Resource</strong></a></li>
            </ul>
            <li class="blink prof">
                <a href="#">
                    <i class="fas fa-user fa-lg"></i> <strong>Profile</strong>
                </a>
            </li>
            <li class="blink">
                <a href="#">
                    <i class="fas fa-cog fa-lg"></i> <strong>System</strong>
                </a>
            </li>
        </ul>
    </div>
  </b-nav>
</template>

<script>
export default {
  name: 'sideNav',
  data () {
    return {
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
/*#header{
  width: calc(100% - 300px);
  float: right;
  text-align: center;
  height: 50px;
  background-color: $navBlue;
  margin-bottom: 15px;
  color: white;
  a {
    &:hover{
      color: $accentRed;
    };
    &:last-child{
      margin: auto 24px auto 24px;
    };
      
    &:hover{
      text-decoration: none;
    };
    color: $navLink;
  }
  span{
  font-size: small;
  }
}*/

</style>
