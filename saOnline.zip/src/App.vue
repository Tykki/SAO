<template>
  <div id="app">
    <sao-header />
    <side-nav />
    <router-view></router-view>
    <sao-footer />
  </div>
</template>

<script>
import Header from '@/components/Header'
import SideNav from '@/components/SideNav'
import Footer from '@/components/Footer'
// import {start} from './assets/index.js'

export default {
  name: 'app',
  components: {
    'sao-header': Header,
    'side-nav': SideNav,
    'sao-footer': Footer
  }
}
</script>

<style lang="scss">
@import "./assets/scss/styles.scss";

</style>
